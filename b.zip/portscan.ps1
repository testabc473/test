$list = ".\computers.txt"
$port = $($args[0])
$results = ".\scanresults.$port.txt"
 
foreach($line in Get-Content $list) {
  $x = (type $results | select-string "^$line,$port,")
  if ($x) {
    Write-Host "port $port on $line already checked"
    continue
  }
  $output = "$line,$port,"
 
  $c = new-object system.net.sockets.tcpclient
  try {
    $c.Connect($line,$port)
  } catch {}
  if ($c.Connected) {
    $output += "True"
  } else {
    $output += "False"
  }
  Write-Host "$output"
  echo $output >>$results
}
